import { httpRouter } from "convex/server";
import { httpAction } from "./_generated/server";
import { internal } from "./_generated/api";

const http = httpRouter();

http.route({
  path: "/evolution-webhook",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    const payload = await request.json();

    // We only care about text messages for now
    if (
      payload.event === "messages.upsert" &&
      payload.data.message?.conversation
    ) {
      const messageData = payload.data;
      const sender = messageData.key.remoteJid.split("@")[0];
      const authorName = messageData.pushName ?? sender;
      const body = messageData.message.conversation;

      // Find or create channel
      let channel = await ctx.runQuery(internal.channels.getChannelByNumber, {
        whatsappNumber: sender,
      });

      if (!channel) {
        const newChannelId = await ctx.runMutation(
          internal.channels.createChannel,
          {
            name: authorName,
            whatsappNumber: sender,
          }
        );
        const newChannel = await ctx.runQuery(internal.channels.getChannelById, { channelId: newChannelId });
        if (!newChannel) {
          // This should not happen
          throw new Error("Could not find newly created channel");
        }
        channel = newChannel;
      }

      if (!channel) {
        throw new Error("Channel could not be found or created.");
      }

      // Insert message
      await ctx.runMutation(internal.messages.insertMessage, {
        channelId: channel._id,
        authorName: authorName,
        body: body,
        source: "whatsapp",
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    });
  }),
});

export default http;
