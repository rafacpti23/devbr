import { v } from "convex/values";
import { internalMutation, internalQuery } from "./_generated/server";

export const getChannelById = internalQuery({
  args: { channelId: v.id("channels") },
  handler: async (ctx, { channelId }) => {
    return await ctx.db.get(channelId);
  },
});

export const getChannelByNumber = internalQuery({
  args: { whatsappNumber: v.string() },
  handler: async (ctx, { whatsappNumber }) => {
    return await ctx.db
      .query("channels")
      .withIndex("by_whatsapp_number", (q) => q.eq("whatsappNumber", whatsappNumber))
      .unique();
  },
});

export const createChannel = internalMutation({
  args: { name: v.string(), whatsappNumber: v.string() },
  handler: async (ctx, args) => {
    let defaultQueue = await ctx.db
      .query("queues")
      .withIndex("by_name", (q) => q.eq("name", "Geral"))
      .unique();

    if (!defaultQueue) {
      defaultQueue = {
        _id: await ctx.db.insert("queues", { name: "Geral" }),
        _creationTime: Date.now(),
        name: "Geral",
      };
    }

    return await ctx.db.insert("channels", {
      name: args.name,
      whatsappNumber: args.whatsappNumber,
      status: "queued",
      queueId: defaultQueue._id,
    });
  },
});
