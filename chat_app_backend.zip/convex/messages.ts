import { v } from "convex/values";
import { internalMutation } from "./_generated/server";
import { Id } from "./_generated/dataModel";

export const insertMessage = internalMutation({
    args: {
        channelId: v.id("channels"),
        authorName: v.string(),
        body: v.string(),
        source: v.string(),
    },
    handler: async (ctx, args) => {
        await ctx.db.insert("messages", {
            channelId: args.channelId,
            authorName: args.authorName,
            body: args.body,
            source: args.source,
        });
    }
})
