"use node";

import { internalAction } from "./_generated/server";
import { v } from "convex/values";

export const sendMessageToWhatsapp = internalAction({
  args: { to: v.string(), body: v.string() },
  handler: async (_, { to, body }) => {
    const evolutionUrl = process.env.EVOLUTION_API_URL;
    const evolutionApiKey = process.env.EVOLUTION_API_KEY;
    const evolutionInstance = process.env.EVOLUTION_INSTANCE_NAME;

    console.log("Attempting to send message via Evolution API...");
    console.log(`URL: ${evolutionUrl}, Instance: ${evolutionInstance}`);

    if (!evolutionUrl || !evolutionApiKey || !evolutionInstance) {
      console.error("Evolution API environment variables are not set.");
      throw new Error("Evolution API environment variables are not set.");
    }

    const remoteJid = `${to.replace(/\D/g, "")}@s.whatsapp.net`;
    const requestUrl = `${evolutionUrl}/message/sendText/${evolutionInstance}`;
    const requestBody = {
      number: remoteJid,
      options: {
        delay: 1200,
        presence: "composing",
      },
      text: body, // Corrected from textMessage: { text: body }
    };

    console.log(`Making POST request to: ${requestUrl}`);
    console.log("Request body:", JSON.stringify(requestBody, null, 2));

    try {
      const response = await fetch(requestUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: evolutionApiKey,
        },
        body: JSON.stringify(requestBody),
      });

      const responseBody = await response.text();
      console.log(`Evolution API response status: ${response.status}`);
      console.log(`Evolution API response body: ${responseBody}`);

      if (!response.ok) {
        console.error("Failed to send message. Full response:", responseBody);
        throw new Error(
          `Evolution API request failed with status ${response.status}: ${responseBody}`
        );
      }
      console.log("Message sent successfully.");
    } catch (error) {
      console.error("Error sending message via Evolution API:", error);
      throw error;
    }
  },
});
