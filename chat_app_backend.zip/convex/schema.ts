import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  queues: defineTable({
    name: v.string(),
  }).index("by_name", ["name"]),

  channels: defineTable({
    name: v.string(),
    whatsappNumber: v.string(),
    status: v.union(
      v.literal("queued"),
      v.literal("open"),
      v.literal("closed")
    ),
    queueId: v.id("queues"),
  })
    .index("by_whatsapp_number", ["whatsappNumber"])
    .index("by_queue_and_status", ["queueId", "status"]),

  messages: defineTable({
    channelId: v.id("channels"),
    authorId: v.optional(v.id("users")),
    authorName: v.string(),
    body: v.string(),
    source: v.string(), // "app" or "whatsapp"
  }).index("by_channel", ["channelId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
