import { query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getMetrics = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const allChannels = await ctx.db.query("channels").collect();
    const queued = allChannels.filter((c) => c.status === "queued").length;
    const open = allChannels.filter((c) => c.status === "open").length;
    const closed = allChannels.filter((c) => c.status === "closed").length;

    return {
      queued,
      open,
      closed,
      total: allChannels.length,
    };
  },
});

export const listUsers = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }
    // This is a simplified user list. In a real app, you'd want role-based access control.
    return await ctx.db.query("users").collect();
  },
});
