// Queries and mutations for managing queues.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const listQueues = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }
    return await ctx.db.query("queues").order("desc").collect();
  },
});

export const createQueue = mutation({
  args: { name: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("You must be logged in.");
    }
    const existing = await ctx.db
      .query("queues")
      .withIndex("by_name", (q) => q.eq("name", args.name))
      .unique();
    if (existing) {
      throw new Error("Queue with that name already exists.");
    }
    if (args.name.trim().length === 0) {
      throw new Error("Queue name cannot be empty.");
    }
    return await ctx.db.insert("queues", { name: args.name });
  },
});
