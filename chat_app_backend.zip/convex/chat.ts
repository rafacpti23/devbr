import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";
import { Id } from "./_generated/dataModel";

export const listChannelsByQueueAndStatus = query({
  args: {
    queueId: v.id("queues"),
    status: v.union(
      v.literal("queued"),
      v.literal("open"),
      v.literal("closed")
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }
    return await ctx.db
      .query("channels")
      .withIndex("by_queue_and_status", (q) =>
        q.eq("queueId", args.queueId).eq("status", args.status)
      )
      .order("desc")
      .collect();
  },
});

export const createChannel = mutation({
  args: { name: v.string(), whatsappNumber: v.string(), queueId: v.id("queues") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("You must be logged in to create a channel.");
    }
    return await ctx.db.insert("channels", {
      name: args.name,
      whatsappNumber: args.whatsappNumber,
      status: "open",
      queueId: args.queueId,
    });
  },
});

export const openChannel = mutation({
  args: { channelId: v.id("channels") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("You must be logged in.");
    }
    const channel = await ctx.db.get(args.channelId);
    if (channel?.status === "queued") {
      await ctx.db.patch(args.channelId, { status: "open" });
    }
  },
});

export const updateChannelStatus = mutation({
  args: {
    channelId: v.id("channels"),
    status: v.union(
      v.literal("queued"),
      v.literal("open"),
      v.literal("closed")
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("You must be logged in.");
    }
    await ctx.db.patch(args.channelId, { status: args.status });
  },
});

export const transferChannelQueue = mutation({
  args: {
    channelId: v.id("channels"),
    queueId: v.id("queues"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("You must be logged in.");
    }
    await ctx.db.patch(args.channelId, { queueId: args.queueId });
  },
});

export const listMessages = query({
  args: { channelId: v.id("channels") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }
    return await ctx.db
      .query("messages")
      .withIndex("by_channel", (q) => q.eq("channelId", args.channelId))
      .collect();
  },
});

export const sendMessage = mutation({
  args: { channelId: v.id("channels"), body: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("You must be logged in to send a message.");
    }
    const user = await ctx.db.get(userId);
    if (!user) {
      throw new Error("User not found.");
    }
    const channel = await ctx.db.get(args.channelId);
    if (!channel) {
      throw new Error("Channel not found.");
    }
    const authorName = user.name ?? "Agente";
    await ctx.db.insert("messages", {
      channelId: args.channelId,
      authorId: userId,
      authorName: authorName,
      body: args.body,
      source: "app",
    });
    const whatsappMessageBody = `*${authorName}*:\n${args.body}`;
    await ctx.scheduler.runAfter(0, internal.evolution.sendMessageToWhatsapp, {
      to: channel.whatsappNumber,
      body: whatsappMessageBody,
    });
  },
});
