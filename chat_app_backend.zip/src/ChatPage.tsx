import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { FormEvent, useEffect, useRef, useState } from "react";
import { Doc, Id } from "../convex/_generated/dataModel";

type Status = "queued" | "open" | "closed";

const STATUS_MAP: Record<Status, string> = {
  queued: "Não Atendidos",
  open: "Meus Tickets",
  closed: "Fechados",
};

export function ChatPage() {
  const [selectedChannel, setSelectedChannel] = useState<Id<"channels"> | null>(
    null
  );
  const [selectedQueue, setSelectedQueue] = useState<Id<"queues"> | null>(null);
  const [statusFilter, setStatusFilter] = useState<Status>("queued");

  const queues = useQuery(api.queues.listQueues) ?? [];
  const channels =
    useQuery(
      api.chat.listChannelsByQueueAndStatus,
      selectedQueue ? { queueId: selectedQueue, status: statusFilter } : "skip"
    ) ?? [];

  const queuedTicketsInAllQueues = useQuery(
    api.chat.listChannelsByQueueAndStatus,
    queues.length > 0
      ? { queueId: queues[0]._id, status: "queued" }
      : "skip"
  );
  const prevQueuedCount = useRef(queuedTicketsInAllQueues?.length);
  const notificationSound = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    notificationSound.current = new Audio("/notification.mp3");
  }, []);

  useEffect(() => {
    const currentCount = queuedTicketsInAllQueues?.length ?? 0;
    if (
      prevQueuedCount.current !== undefined &&
      currentCount > prevQueuedCount.current
    ) {
      notificationSound.current?.play().catch(e => console.error("Error playing sound:", e));
    }
    prevQueuedCount.current = currentCount;
  }, [queuedTicketsInAllQueues]);

  useEffect(() => {
    if (!selectedQueue && queues.length > 0) {
      setSelectedQueue(queues[0]._id);
    }
  }, [queues, selectedQueue]);

  useEffect(() => {
    if (selectedChannel && !channels.find((c) => c._id === selectedChannel)) {
      setSelectedChannel(null);
    }
  }, [channels, selectedChannel]);

  const openChannel = useMutation(api.chat.openChannel);

  function handleSelectChannel(channelId: Id<"channels">) {
    const channel = channels.find((c) => c._id === channelId);
    if (channel?.status === "queued") {
      openChannel({ channelId });
    }
    setSelectedChannel(channelId);
  }

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      <div className="w-80 border-r flex flex-col">
        <QueueList
          queues={queues}
          selectedQueue={selectedQueue}
          onSelectQueue={setSelectedQueue}
        />
        <div className="p-2 border-b border-t">
          <div className="flex bg-gray-200 rounded-md p-1">
            {(Object.keys(STATUS_MAP) as Status[]).map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`flex-1 text-sm py-1 px-2 rounded-md transition-colors ${
                  statusFilter === status
                    ? "bg-white shadow font-semibold"
                    : "hover:bg-gray-100"
                }`}
              >
                {STATUS_MAP[status]}
              </button>
            ))}
          </div>
        </div>
        <ChannelList
          channels={channels}
          selectedChannel={selectedChannel}
          onSelectChannel={handleSelectChannel}
        />
      </div>

      <div className="flex-1 flex flex-col">
        {selectedChannel ? (
          <MessagePanel
            key={selectedChannel}
            channelId={selectedChannel}
            onStatusChange={() => setSelectedChannel(null)}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-secondary">
              Selecione um ticket para começar
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function QueueList({
  queues,
  selectedQueue,
  onSelectQueue,
}: {
  queues: Doc<"queues">[];
  selectedQueue: Id<"queues"> | null;
  onSelectQueue: (id: Id<"queues">) => void;
}) {
  return (
    <div className="p-2">
      <h3 className="text-xs font-bold uppercase text-gray-500 px-2 mb-1">Filas</h3>
      {queues.map((queue) => (
        <button
          key={queue._id}
          onClick={() => onSelectQueue(queue._id)}
          className={`w-full text-left p-2 rounded font-semibold ${
            selectedQueue === queue._id
              ? "bg-primary/10 text-primary"
              : "hover:bg-gray-100"
          }`}
        >
          {queue.name}
        </button>
      ))}
    </div>
  );
}

function ChannelList({
  channels,
  selectedChannel,
  onSelectChannel,
}: {
  channels: Doc<"channels">[];
  selectedChannel: Id<"channels"> | null;
  onSelectChannel: (id: Id<"channels">) => void;
}) {
  return (
    <ul className="flex-1 overflow-y-auto p-2">
      {channels.map((channel) => (
        <li key={channel._id}>
          <button
            className={`w-full text-left p-2 rounded mb-1 ${
              selectedChannel === channel._id
                ? "bg-primary text-white"
                : "hover:bg-gray-100"
            }`}
            onClick={() => onSelectChannel(channel._id)}
          >
            <div className="font-bold">{channel.name}</div>
            <div className="text-sm opacity-70">
              {channel.whatsappNumber}
            </div>
          </button>
        </li>
      ))}
    </ul>
  );
}

function MessagePanel({
  channelId,
  onStatusChange,
}: {
  channelId: Id<"channels">;
  onStatusChange: () => void;
}) {
  const messages = useQuery(api.chat.listMessages, { channelId }) ?? [];
  const sendMessage = useMutation(api.chat.sendMessage);
  const updateStatus = useMutation(api.chat.updateChannelStatus);
  const transferQueue = useMutation(api.chat.transferChannelQueue);
  const queues = useQuery(api.queues.listQueues) ?? [];
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  function handleSendMessage(e: FormEvent) {
    e.preventDefault();
    if (newMessage) {
      sendMessage({ channelId, body: newMessage });
      setNewMessage("");
    }
  }

  async function handleStatusChange(status: Status) {
    await updateStatus({ channelId, status });
    onStatusChange();
  }

  async function handleTransfer(queueId: Id<"queues">) {
    await transferQueue({ channelId, queueId });
    onStatusChange();
  }

  return (
    <div className="flex-1 flex flex-col">
      <div className="p-2 border-b flex justify-end items-center gap-2">
        <select
          onChange={(e) => handleTransfer(e.target.value as Id<"queues">)}
          className="bg-white border rounded px-2 py-1 text-sm"
        >
          <option>Transferir para...</option>
          {queues.map((q) => (
            <option key={q._id} value={q._id}>
              {q.name}
            </option>
          ))}
        </select>
        <button
          onClick={() => handleStatusChange("queued")}
          className="px-3 py-1 text-sm bg-yellow-500 text-white rounded hover:bg-yellow-600"
        >
          Enviar para Fila
        </button>
        <button
          onClick={() => handleStatusChange("closed")}
          className="px-3 py-1 text-sm bg-red-500 text-white rounded hover:bg-red-600"
        >
          Fechar Ticket
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 bg-gray-100">
        {messages.map((message) => (
          <div
            key={message._id}
            className={`flex flex-col mb-3 ${
              message.source === "app" ? "items-end" : "items-start"
            }`}
          >
            <div
              className={`max-w-lg p-3 rounded-lg shadow ${
                message.source === "app"
                  ? "bg-primary text-white"
                  : "bg-white"
              }`}
            >
              <div className="font-bold text-sm mb-1">
                {message.authorName}
              </div>
              <div>{message.body}</div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <form onSubmit={handleSendMessage} className="flex gap-2 p-4 border-t">
        <input
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Digite uma mensagem..."
          className="flex-1 px-4 py-2 border rounded-full"
        />
        <button
          type="submit"
          disabled={!newMessage}
          className="px-6 py-2 bg-primary text-white rounded-full disabled:opacity-50"
        >
          Enviar
        </button>
      </form>
    </div>
  );
}
