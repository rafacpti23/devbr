import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { FormEvent, useState } from "react";
import { toast } from "sonner";

export function DashboardPage() {
  const metrics = useQuery(api.dashboard.getMetrics);
  const users = useQuery(api.dashboard.listUsers);
  const queues = useQuery(api.queues.listQueues);

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard title="Não Atendidos" value={metrics?.queued} />
        <MetricCard title="Em Atendimento" value={metrics?.open} />
        <MetricCard title="Fechados" value={metrics?.closed} />
        <MetricCard title="Total" value={metrics?.total} />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold mb-4">Filas de Atendimento</h2>
          <div className="bg-white shadow rounded-lg">
            <NewQueueForm />
            <ul className="divide-y divide-gray-200">
              {queues?.map((queue) => (
                <li key={queue._id} className="px-6 py-4 font-semibold">
                  {queue.name}
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-bold mb-4">Usuários do Sistema</h2>
          <div className="bg-white shadow rounded-lg">
            <ul className="divide-y divide-gray-200">
              {users?.map((user) => (
                <li key={user._id} className="px-6 py-4">
                  <p className="font-semibold">
                    {user.name ?? "Novo Usuário"}
                  </p>
                  <p className="text-sm text-gray-500">{user.email}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

function NewQueueForm() {
  const [newQueueName, setNewQueueName] = useState("");
  const createQueue = useMutation(api.queues.createQueue);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    try {
      await createQueue({ name: newQueueName });
      setNewQueueName("");
      toast.success("Fila criada com sucesso!");
    } catch (error) {
      toast.error((error as Error).message);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="p-4 border-b flex gap-2">
      <input
        value={newQueueName}
        onChange={(e) => setNewQueueName(e.target.value)}
        placeholder="Nome da nova fila"
        className="flex-1 px-2 py-1 border rounded"
      />
      <button
        type="submit"
        disabled={!newQueueName}
        className="px-3 py-1 bg-primary text-white rounded disabled:opacity-50"
      >
        Criar Fila
      </button>
    </form>
  );
}

function MetricCard({
  title,
  value,
}: {
  title: string;
  value: number | undefined;
}) {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
      <p className="text-3xl font-bold mt-2">{value ?? "..."}</p>
    </div>
  );
}
